import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';
import AboutMe from './components/AboutMe';

const projects = [
  {
    id: 1,
    title: 'Communication Assistant Board',
    category: 'PRODUCT DESIGN',
    image: 'https://drive.google.com/thumbnail?id=1EE2x2s-CVpN5gs4Yl4nD_tTa8V-aYMJO&sz=w800',
    details: {
      problem: "Seniors with mobility or cognitive limitations struggle to communicate with family members.",
      solution: "Designed a simple push-button communication board to help seniors communicate more easily.",
      solutionImage: "https://drive.google.com/thumbnail?id=1EE2x2s-CVpN5gs4Yl4nD_tTa8V-aYMJO&sz=w1200",
      role: "Product Designer",
      timeline: "1.5 years",
      processStages: [
        {
          title: "Empathize",
          images: [
            "https://drive.google.com/thumbnail?id=1B-33DbWDE9d3XHs1RJCltqeNwNCSFQKI&sz=w1200",
            "https://drive.google.com/thumbnail?id=1-YYW-tRmAgwU4twKX5lo37cJCJGxQV-m&sz=w1200",
            "https://drive.google.com/thumbnail?id=1rwvdWOUaF0iLgv8b4EzT0sGppcughdBL&sz=w1200",
            "https://drive.google.com/thumbnail?id=1vsy-q8N0ITEarGAehwh3FjY9CPCbtO5v&sz=w1200"
          ]
        },
        {
          title: "Define",
          images: [
            "https://drive.google.com/thumbnail?id=1kyAwRDzHyUnzwu7LjndsmicRa7Kl1eKS&sz=w1200",
            "https://drive.google.com/thumbnail?id=1CJuLlv_aBVjJTQAgut6ZV0GsPEFV5lSH&sz=w1200"
          ]
        },
        {
          title: "Ideate",
          images: [
            "https://drive.google.com/thumbnail?id=13H5cz1JOreZ7KA6C7HZMoWR9Q9u7qfqK&sz=w1200",
            "https://drive.google.com/thumbnail?id=12mkvXOazCwxiGTG3bgSXxmfxeO5zJEIW&sz=w1200",
            "https://drive.google.com/thumbnail?id=1qgcgLg0uw1nwj6lHmIaU7JZFbdkCjNSU&sz=w1200"
          ]
        },
        {
          title: "Prototype",
          text: "Designed and created a low-fidelity prototype of the push-button board to explore layout, button size, and usability.",
          images: []
        },
        {
          title: "Test",
          images: [
            "https://drive.google.com/thumbnail?id=1kG5a0uYGZSxypW2zkK7d8kdWCN3_yZmp&sz=w1200",
            "https://drive.google.com/thumbnail?id=1ApNsYrLSVZ5JVty5mg1ByE3q4NuVmvxw&sz=w1200"
          ]
        }
      ]
    }
  },
  {
    id: 2,
    title: 'ThriveMoms App',
    category: 'UI/UX DESIGN',
    image: 'https://drive.google.com/thumbnail?id=1aR-PdvWG34IqATlEdjFVWhhSsHkctvxT&sz=w1200',
    details: {
      problem: "Busy mothers often struggle to maintain consistent fitness routines due to limited time, lack of motivation, and minimal social support.",
      solution: "Designed ThriveMom, a community fitness app with Pick & Choose workout cards, a Live Map to find partners, and community-driven events.",
      solutionImages: [
        "https://drive.google.com/thumbnail?id=1RAFidxvUm5URb30FlRdhVWBpT2p49ACl&sz=w1200",
        "https://drive.google.com/thumbnail?id=1EQmaEb0cWe0w8B8LTVLCRGKbZSel49zd&sz=w1200",
        "https://drive.google.com/thumbnail?id=1lMkygV8hTRIHajgUBD0ifFLaJ7MUQOPD&sz=w1200",
        "https://drive.google.com/thumbnail?id=1BFad5I6KwWP_mGikWGE3LKz4eoKK-k95&sz=w1200",
        "https://drive.google.com/thumbnail?id=11DsJ_J3pBeKgve5iwCjhuVaxT2tZ9S3b&sz=w1200",
        "https://drive.google.com/thumbnail?id=1yVvqd5-pNVJTUkYPIv0tNcF1aBhS3X4d&sz=w1200"
      ],
      role: "User Experience Designer",
      timeline: "3 months",
      processStages: [
        {
          title: "Empathize",
          images: [
            "https://drive.google.com/thumbnail?id=1AeFpLFKnHfcoKD3y7Zx6CB6uR9snvvtH&sz=w1200",
            "https://drive.google.com/thumbnail?id=1b_pw9G5djDXZ5UBhuFsAwZ6KUehWbfyz&sz=w1200",
            "https://drive.google.com/thumbnail?id=12GQ6pLd5ch_QhIgcDlNWtiqWM4eoGwe0&sz=w1200"
          ]
        },
        {
          title: "Define",
          images: [
            "https://drive.google.com/thumbnail?id=1pb3gjjert-BTikP7JdOcQ0-IMAiNWi5z&sz=w1200",
            "https://drive.google.com/thumbnail?id=1MIwhAfUs7kkUIyHojphMpk9zWgBag20O&sz=w1200",
            "https://drive.google.com/thumbnail?id=1Gy3dh1bx2IQQVuMd2Ez4rjUUEMsHggy7&sz=w1200",
            "https://drive.google.com/thumbnail?id=1wnAgCD9ImLQxrVds9MncBdu2TYDK4aXC&sz=w1200",
            "https://drive.google.com/thumbnail?id=175aVVRbaGvSjpgTajrBQuS9IUs4DexZp&sz=w1200"
          ]
        },
        {
          title: "Ideate",
          images: [
            "https://drive.google.com/thumbnail?id=1f55ZbCmFC72EqAo4IYiP4t5qJKPsPNIW&sz=w1200",
            "https://drive.google.com/thumbnail?id=1rj7-rudjC5BIaT8V_BcITtHS65U6rx5o&sz=w1200"
          ]
        },
        {
          title: "Prototype and Test",
          images: [
            "https://drive.google.com/thumbnail?id=1XURrrC5lSj4UiL24wX83TLqjG01IgzQG&sz=w1200"
          ]
        }
      ]
    }
  },
  {
    id: 3,
    title: 'Sephora',
    category: 'Content Designer',
    image: 'https://drive.google.com/thumbnail?id=11gG8GhGOBV8vzM3mCEF208qcsF-mELSA&sz=w1200',
    details: {
      problem: "Unstructured Instagram content weakens engagement and audience trust.",
      solution: "Develop a content framework focused on audience needs, visual consistency, and engagement.",
      beforeAfter: {
        before: "https://drive.google.com/thumbnail?id=1K5Hg9PkJANqRd5qnAXxHi--96J4dz9mq&sz=w1200",
        after: "https://drive.google.com/thumbnail?id=1iGYIJAmH-xmT50EW-4un-tlKZJaZkIMU&sz=w1200"
      },
      contentCreated: [
        "https://drive.google.com/thumbnail?id=1FANtasJvr5Ne9DLDVafKqYZ1YDO4xsmz&sz=w1200",
        "https://drive.google.com/thumbnail?id=1IibnQAdZLdR8-lyWtl5bsk4woW5h_hmY&sz=w1200",
        "https://drive.google.com/thumbnail?id=1KAduTMSaTzY4vuO1lUshzd08KXINlT36&sz=w1200",
        "https://drive.google.com/thumbnail?id=1JIjqwn-h9vZX33VAZbRDikFPspX29csW&sz=w1200",
        "https://drive.google.com/thumbnail?id=1xq0USqqlSxvu_WeewxzKjK3-fRIBNVkD&sz=w1200",
        "https://drive.google.com/thumbnail?id=1ALBqcq4s63z-UmlmF6rt2e74citiPtTs&sz=w1200"
      ],
      role: "Content Designer",
      timeline: "2 weeks",
      processStages: []
    }
  },
  {
    id: 4,
    title: 'Crunch',
    category: 'Content Designer',
    image: 'https://drive.google.com/thumbnail?id=1otvEOejuZt_FAazPYxJeVpa6XNn4Yzxv&sz=w1200',
    details: {
      problem: "Members lacked awareness of class schedules due to unclear communication and limited marketing.",
      solution: "Designed physical and digital content while analyzing engagement insights to improve visibility and performance.",
      role: "Content Designer",
      timeline: "1 year",
      physicalMarketing: [
        "https://drive.google.com/thumbnail?id=1fugLFNAaHBbyuTcG1Ut0zos86m2y_LvO&sz=w1200",
        "https://drive.google.com/thumbnail?id=11y7TKqXOKQindtSyPr29Mmf9QROnM5Ja&sz=w1200"
      ],
      socialMediaContent: [
        "https://drive.google.com/thumbnail?id=1_GIWIyyohh5Ejt1b67oI8O67mKK1FONK&sz=w1200",
        "https://drive.google.com/thumbnail?id=1MUCSPQgXLwZyiMZC6mj6r7xmYPWer9Sa&sz=w1200",
        "https://drive.google.com/thumbnail?id=1uzxSN9LA3JQxGs80X4Kje9Ee5_oxVm5u&sz=w1200"
      ]
    }
  }
];

export default function App() {
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [showAbout, setShowAbout] = useState(false);

  if (showAbout) {
    return <AboutMe onClose={() => setShowAbout(false)} />;
  }

  return (
    <div className="min-h-screen bg-white text-black font-serif overflow-x-hidden selection:bg-[#E2FA8E] selection:text-black">
      {/* Header */}
      <header className="px-6 md:px-12 py-6 flex justify-between items-center">
        <a href="/" className="inline-block hover:scale-110 transition-transform">
          <svg width="45" height="45" viewBox="0 0 100 100" fill="none" stroke="black" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
            <path d="M50 45 C40 10 75 10 60 45 C95 30 95 70 65 60 C80 95 40 100 45 65 C10 90 0 55 35 50 C5 25 35 0 50 45 Z" transform="rotate(-20 50 50)" />
          </svg>
        </a>
        <nav className="flex gap-3 md:gap-6">
          <a href="#projects" className="px-5 md:px-8 py-1 md:py-1.5 border border-black text-sm md:text-lg hover:bg-black hover:text-white transition-colors" style={{ borderRadius: '50%' }}>Projects</a>
          <button onClick={() => setShowAbout(true)} className="px-5 md:px-8 py-1 md:py-1.5 border border-black text-sm md:text-lg hover:bg-black hover:text-white transition-colors" style={{ borderRadius: '50%' }}>About me</button>
          <a href="#contact" className="px-5 md:px-8 py-1 md:py-1.5 border border-black text-sm md:text-lg hover:bg-black hover:text-white transition-colors" style={{ borderRadius: '50%' }}>Contact</a>
        </nav>
      </header>

      {/* Main Content */}
      <main className="px-4 md:px-12 pt-20 md:pt-32 pb-32 max-w-[1600px] mx-auto text-center flex flex-col items-center justify-center">
        <div className="text-[3.5vw] md:text-[2.5vw] lg:text-[40px] xl:text-[50px] leading-[1.2] tracking-tight max-w-[100vw]">
          
          {/* Line 1 */}
          <div className="whitespace-nowrap flex items-center justify-center flex-wrap md:flex-nowrap gap-y-4">
            <span className="italic pr-1 md:pr-3">Hi,</span>
            <motion.div 
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
              <svg viewBox="0 0 100 100" fill="none" stroke="#0033FF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="inline-block align-middle mx-1 md:mx-3 w-[9vw] h-[9vw] md:w-[70px] md:h-[70px] lg:w-[85px] lg:h-[85px]">
                <path d="M50 45 C40 10 75 10 60 45 C95 30 95 70 65 60 C80 95 40 100 45 65 C10 90 0 55 35 50 C5 25 35 0 50 45 Z" />
              </svg>
            </motion.div>
            <span className="pr-1 md:pr-3">I'm Rousha Moshtaghian</span>
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="inline-block h-[11vw] md:h-[80px] lg:h-[100px] xl:h-[120px] shrink-0 align-middle mx-1 md:mx-3"
            >
              <img src="https://drive.google.com/thumbnail?id=1vN4bT_gNl917RkCn6uYPIyUnKL6wZUC_&sz=w800" alt="Rousha Moshtaghian" className="h-full w-auto rounded-2xl object-contain" referrerPolicy="no-referrer" />
            </motion.div>
          </div>
          
          {/* Line 2 */}
          <div className="whitespace-nowrap flex items-center justify-center mt-2 md:mt-6 flex-wrap md:flex-nowrap gap-y-4">
            <motion.div whileHover={{ scale: 1.05 }}>
              <svg viewBox="0 0 140 60" fill="none" xmlns="http://www.w3.org/2000/svg" className="inline-block align-middle mx-1 md:mx-3 w-[16vw] md:w-[120px] lg:w-[150px]">
                <mask id="pill-mask-1">
                  <rect width="140" height="60" rx="30" fill="white"/>
                </mask>
                <g mask="url(#pill-mask-1)">
                  <rect width="140" height="60" fill="#FFAEEA"/>
                  <path d="M45 0 H85 L65 60 Z" fill="#FF6230"/>
                </g>
              </svg>
            </motion.div>
            <span className="italic pr-1 md:pr-3">a designer</span>
            <motion.div 
              animate={{ rotate: [0, -10, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
            >
              <svg viewBox="0 0 100 100" fill="none" stroke="#7B3DFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="inline-block align-middle mx-1 md:mx-3 w-[8vw] h-[8vw] md:w-[60px] md:h-[60px] lg:w-[75px] lg:h-[75px]">
                <path d="M50 45 C40 10 75 10 60 45 C95 30 95 70 65 60 C80 95 40 100 45 65 C10 90 0 55 35 50 C5 25 35 0 50 45 Z" transform="rotate(45 50 50)" />
              </svg>
            </motion.div>
          </div>

        </div>
      </main>

      {/* Statement Section */}
      <section className="px-4 md:px-12 py-16 md:py-32 max-w-[1200px] mx-auto text-center">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-[20.76px] leading-[1.3] tracking-tight text-gray-900"
        >
          Focused on clarity, simplicity, and fewer “Where do I click?” moments.
        </motion.h2>
      </section>

      {/* Projects Section */}
      <section id="projects" className="px-4 md:px-12 pb-32 max-w-[1600px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {projects.map((project) => (
            <motion.div 
              key={project.id} 
              className="cursor-pointer"
              onClick={() => setSelectedProject(project)}
              initial="initial"
              whileInView="animate"
              whileHover="hover"
              viewport={{ once: true, margin: "-100px" }}
              variants={{
                initial: { opacity: 0, y: 20 },
                animate: { opacity: 1, y: 0, transition: { duration: 0.5 } }
              }}
            >
              <div className="relative overflow-hidden rounded-2xl md:rounded-3xl mb-4 aspect-[4/3] bg-gray-100">
                <motion.img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover"
                  variants={{
                    initial: { scale: 1 },
                    hover: { scale: 1.1, transition: { duration: 0.7, ease: "easeOut" } }
                  }}
                  referrerPolicy="no-referrer"
                />
                <motion.div 
                  className="absolute inset-0 bg-black/20 flex items-center justify-center pointer-events-none"
                  variants={{
                    initial: { opacity: 0 },
                    hover: { opacity: 1, transition: { duration: 0.5 } }
                  }}
                >
                  <motion.div 
                    className="bg-white text-black px-8 py-3.5 rounded-full font-sans text-sm tracking-wide font-medium shadow-xl"
                    variants={{
                      initial: { y: 20, opacity: 0 },
                      hover: { y: 0, opacity: 1, transition: { duration: 0.5, ease: "easeOut" } }
                    }}
                  >
                    View Project
                  </motion.div>
                </motion.div>
              </div>
              <div className="flex justify-between items-center px-1 font-sans">
                <h3 className="text-lg md:text-xl font-medium text-gray-900">{project.title}</h3>
                <span className="text-xs md:text-sm text-gray-400 tracking-wider uppercase">{project.category}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="px-4 md:px-12 py-24 md:py-40 max-w-[1400px] mx-auto font-sans relative overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-stretch min-h-[40vh] md:min-h-[300px]"
        >
          {/* Left Side */}
          <div className="flex flex-col justify-between h-full w-full md:w-1/2 relative z-10">
            <div className="flex items-center gap-4 mb-16 md:mb-0">
              <h2 className="text-[60px] font-bold text-black tracking-tighter leading-[200px]">
                Contact
              </h2>
              <motion.svg 
                animate={{ rotate: 360 }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                width="40" height="40" viewBox="0 0 100 100" className="text-[#0033FF] hidden md:block"
              >
                <path d="M50 0 L55 45 L100 50 L55 55 L50 100 L45 55 L0 50 L45 45 Z" fill="currentColor" />
              </motion.svg>
            </div>
            
            <div className="flex flex-wrap gap-4 mt-auto">
              <motion.a 
                whileHover={{ scale: 1.05, backgroundColor: "#3f3f46" }}
                whileTap={{ scale: 0.95 }}
                href="mailto:roshamhtt@gmail.com" 
                className="px-6 py-3 sm:px-8 sm:py-4 bg-zinc-800 text-white rounded-full text-base sm:text-lg font-medium transition-colors flex items-center gap-2 shadow-sm"
              >
                Email Me
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
              </motion.a>
              <motion.a 
                whileHover={{ scale: 1.05, backgroundColor: "#3f3f46" }}
                whileTap={{ scale: 0.95 }}
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="px-6 py-3 sm:px-8 sm:py-4 bg-zinc-800 text-white rounded-full text-base sm:text-lg font-medium transition-colors flex items-center gap-2 shadow-sm"
              >
                LinkedIn
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
              </motion.a>
            </div>
          </div>

          {/* Right Side */}
          <div className="w-full md:w-1/2 flex items-center mt-16 md:mt-0 md:pl-12 lg:pl-24 relative">
            <motion.p 
              className="text-2xl md:text-3xl lg:text-4xl text-gray-500 font-medium leading-[1.4] tracking-tight max-w-xl"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={{
                visible: { transition: { staggerChildren: 0.04 } },
                hidden: {}
              }}
            >
              {"If you made it this far, we should probably work together.".split(" ").map((word, i) => (
                <motion.span 
                  key={i} 
                  className="inline-block mr-2"
                  variants={{
                    hidden: { opacity: 0, y: 20, filter: "blur(4px)" },
                    visible: { opacity: 1, y: 0, filter: "blur(0px)", transition: { type: "spring", damping: 12, stiffness: 100 } }
                  }}
                >
                  {word}
                </motion.span>
              ))}
            </motion.p>
            
            {/* Decorative animated scribble */}
            <motion.svg 
              className="absolute -bottom-16 -right-8 w-32 h-32 text-[#E2FA8E] pointer-events-none hidden lg:block"
              viewBox="0 0 100 100" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="3" 
              strokeLinecap="round"
            >
              <motion.path 
                d="M10,50 Q30,10 50,50 T90,50" 
                initial={{ pathLength: 0 }}
                whileInView={{ pathLength: 1 }}
                transition={{ duration: 2, ease: "easeInOut", repeat: Infinity, repeatType: "reverse" }}
              />
              <motion.path 
                d="M20,70 Q50,90 80,70" 
                initial={{ pathLength: 0 }}
                whileInView={{ pathLength: 1 }}
                transition={{ duration: 2, ease: "easeInOut", repeat: Infinity, repeatType: "reverse", delay: 0.5 }}
              />
            </motion.svg>
          </div>
        </motion.div>
      </section>

      {/* Project Details Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-12 bg-black/80 backdrop-blur-sm"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div 
              initial={{ y: 50, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 20, opacity: 0, scale: 0.95 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-white w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl flex flex-col relative"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative w-full h-[40vh] min-h-[350px] shrink-0 overflow-hidden group rounded-t-3xl">
                <img 
                  src={selectedProject.image} 
                  alt={selectedProject.title} 
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-[20s] ease-out group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                
                {/* Gradient Overlays */}
                <div className="absolute inset-0 bg-black/40"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-transparent"></div>
                
                {/* Close Button */}
                <button 
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-6 right-6 z-20 p-3 bg-white/10 hover:bg-white/20 backdrop-blur-xl border border-white/20 rounded-full transition-all hover:scale-105 shadow-xl group/btn"
                >
                  <X className="w-6 h-6 text-white group-hover/btn:rotate-90 transition-transform duration-300" />
                </button>

                {/* Content */}
                <div className="absolute bottom-0 left-0 w-full p-8 md:p-12 z-10">
                  <motion.div 
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
                  >
                    <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-white/10 backdrop-blur-md border border-white/20 rounded-full text-sm font-semibold tracking-widest uppercase mb-6 shadow-lg text-white">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      {selectedProject.category}
                    </span>
                    <h2 className="text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tighter text-white drop-shadow-lg mb-2">
                      {selectedProject.title}
                    </h2>
                    <div className="w-24 h-1.5 bg-gradient-to-r from-emerald-400 to-cyan-400 rounded-full mt-6 opacity-90 shadow-[0_0_15px_rgba(52,211,153,0.5)]"></div>
                  </motion.div>
                </div>
              </div>

              <div className="p-8 md:p-12 font-sans text-gray-800">
                {selectedProject.details ? (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                      <div className="md:col-span-2 space-y-8">
                      {selectedProject.details.overview && (
                        <div>
                          <h3 className="text-2xl font-bold mb-4 text-black">Overview</h3>
                          <p className="text-lg leading-relaxed text-gray-600">
                            {selectedProject.details.overview}
                          </p>
                        </div>
                      )}

                      {selectedProject.details.problem && (
                        <div>
                          <h3 className="text-2xl font-bold mb-4 text-black">The Problem</h3>
                          <p className="text-lg leading-relaxed text-gray-600">
                            {selectedProject.details.problem}
                          </p>
                        </div>
                      )}

                      {selectedProject.details.solution && (
                        <div>
                          <h3 className="text-2xl font-bold mb-4 text-black">The Solution</h3>
                          <p className="text-lg leading-relaxed text-gray-600">
                            {selectedProject.details.solution}
                          </p>
                          {selectedProject.details.solutionImage && (
                            <img 
                              src={selectedProject.details.solutionImage} 
                              alt="Solution" 
                              className="w-full mt-6 rounded-2xl object-cover"
                              referrerPolicy="no-referrer"
                            />
                          )}
                        </div>
                      )}
                      
                    </div>

                    <div className="space-y-8">
                      <div className="bg-gray-50 p-6 rounded-2xl">
                        <h4 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-2">Role</h4>
                        <p className="text-lg font-medium text-black">{selectedProject.details.role}</p>
                      </div>
                      <div className="bg-gray-50 p-6 rounded-2xl">
                        <h4 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-2">Timeline</h4>
                        <p className="text-lg font-medium text-black">{selectedProject.details.timeline}</p>
                      </div>
                    </div>
                  </div>

                  {selectedProject.details.beforeAfter && (
                    <div className="pt-16 mt-12 border-t border-gray-100">
                      <h3 className="text-3xl font-bold mb-10 text-black">Before & After</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                        <div className="flex flex-col h-full">
                          <h4 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-4 text-center">Before</h4>
                          <img 
                            src={selectedProject.details.beforeAfter.before} 
                            alt="Before" 
                            className="w-full h-full rounded-2xl object-cover shadow-sm opacity-90 hover:opacity-100 transition-opacity"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <motion.div 
                          className="flex flex-col h-full relative"
                          animate={{ y: [0, -8, 0] }}
                          transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-purple-500/20 blur-2xl rounded-3xl -z-10 animate-pulse"></div>
                          <h4 className="text-sm font-bold uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 mb-4 text-center flex items-center justify-center gap-2">
                            <span className="relative flex h-3 w-3">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
                            </span>
                            After
                          </h4>
                          <img 
                            src={selectedProject.details.beforeAfter.after} 
                            alt="After" 
                            className="w-full h-full rounded-2xl object-cover shadow-2xl ring-2 ring-indigo-500/20"
                            referrerPolicy="no-referrer"
                          />
                        </motion.div>
                      </div>
                    </div>
                  )}

                  {selectedProject.details.solutionImages && selectedProject.details.solutionImages.length > 0 && (
                    <div className="pt-16 mt-12 border-t border-gray-100">
                      <h3 className="text-3xl font-bold mb-10 text-black">Prototype Highlights</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {selectedProject.details.solutionImages.map((img: string, idx: number) => (
                          <img 
                            key={idx}
                            src={img} 
                            alt={`Solution detail ${idx + 1}`} 
                            className="w-full rounded-2xl object-cover shadow-sm hover:scale-[1.02] transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedProject.details.contentCreated && selectedProject.details.contentCreated.length > 0 && (
                    <div className="pt-16 mt-12 border-t border-gray-100">
                      <h3 className="text-3xl font-bold mb-10 text-black">Content I Created</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {selectedProject.details.contentCreated.map((img: string, idx: number) => (
                          <img 
                            key={idx}
                            src={img} 
                            alt={`Content created ${idx + 1}`} 
                            className="w-full h-full rounded-2xl object-cover shadow-sm hover:scale-[1.02] transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedProject.details.physicalMarketing && selectedProject.details.physicalMarketing.length > 0 && (
                    <div className="pt-16 mt-12 border-t border-gray-100">
                      <h3 className="text-3xl font-bold mb-10 text-black">Physical Marketing Materials</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        {selectedProject.details.physicalMarketing.map((img: string, idx: number) => (
                          <img 
                            key={idx}
                            src={img} 
                            alt={`Physical marketing ${idx + 1}`} 
                            className="w-full h-full rounded-2xl object-cover shadow-sm hover:scale-[1.02] transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedProject.details.socialMediaContent && selectedProject.details.socialMediaContent.length > 0 && (
                    <div className="pt-16 mt-12 border-t border-gray-100">
                      <h3 className="text-3xl font-bold mb-10 text-black">Social Media Content</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {selectedProject.details.socialMediaContent.map((img: string, idx: number) => (
                          <img 
                            key={idx}
                            src={img} 
                            alt={`Social media content ${idx + 1}`} 
                            className="w-full h-full rounded-2xl object-cover shadow-sm hover:scale-[1.02] transition-transform duration-300"
                            referrerPolicy="no-referrer"
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedProject.details.processStages && selectedProject.details.processStages.length > 0 && (
                    <div className="pt-16 mt-12 border-t border-gray-100">
                      <h3 className="text-3xl font-bold mb-10 text-black">My Process</h3>
                      <div className="space-y-12">
                        {selectedProject.details.processStages.map((stage: any, idx: number) => (
                          <motion.div 
                            key={idx}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true, margin: "-50px" }}
                            transition={{ duration: 0.5, delay: 0.1 }}
                            className="border-l-4 border-gray-200 pl-6 md:pl-8 py-2 relative"
                          >
                            <div className="absolute w-4 h-4 bg-black rounded-full -left-[10px] top-4"></div>
                            <h4 className="text-2xl font-bold text-black mb-4">{stage.title}</h4>
                            {stage.text && (
                              <p className="text-lg leading-relaxed text-gray-600 mb-6 max-w-3xl">
                                {stage.text}
                              </p>
                            )}
                            {stage.images && stage.images.length > 0 && (
                              <div className="grid grid-cols-1 md:grid-cols-6 gap-8">
                                {stage.images.map((img: string, imgIdx: number) => {
                                  let colSpanClass = "md:col-span-3"; // default 2 per row
                                  
                                  if (stage.images.length === 5) {
                                    colSpanClass = imgIdx < 2 ? "md:col-span-3" : "md:col-span-2";
                                  } else if (stage.images.length % 2 !== 0 && imgIdx === stage.images.length - 1) {
                                    colSpanClass = "md:col-span-6 md:w-1/2 md:mx-auto";
                                  }

                                  return (
                                    <img 
                                      key={imgIdx} 
                                      src={img} 
                                      alt={`${stage.title} step ${imgIdx + 1}`} 
                                      className={`w-full h-full rounded-2xl object-cover shadow-sm ${colSpanClass}`}
                                      referrerPolicy="no-referrer"
                                    />
                                  );
                                })}
                              </div>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  )}
                  </>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-xl text-gray-500">More details coming soon.</p>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
