import { useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';

interface AboutMeProps {
  onClose: () => void;
}

export default function AboutMe({ onClose }: AboutMeProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-[#f8f8f8] text-black font-sans relative overflow-x-hidden selection:bg-[#E2FA8E] selection:text-black">
      {/* Subtle vertical line */}
      <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-gray-200 -translate-x-1/2 z-0 hidden md:block"></div>

      {/* Navigation */}
      <div className="absolute top-6 left-6 md:top-12 md:left-12 z-50">
        <motion.button 
          onClick={onClose}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm hover:shadow-md transition-all text-sm font-medium"
        >
          <ArrowLeft size={16} />
          Back to Portfolio
        </motion.button>
      </div>

      <main className="relative z-10 pt-32 pb-24 px-6 md:px-12 max-w-[1400px] mx-auto">
        
        {/* Header Section */}
        <div className="flex justify-center mb-20">
          <div className="relative inline-block text-center">
            <motion.div 
              initial={{ opacity: 0, rotate: -10 }}
              animate={{ opacity: 1, rotate: -5 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="absolute left-[0%] md:left-auto md:right-[95%] top-[-90px] md:top-[-30px] md:mr-2 lg:mr-4 text-gray-500 italic font-serif text-lg md:text-xl text-left w-max"
            >
              Designing things.<br/>Drinking coffee.<br/>Repeat.
            </motion.div>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-5xl md:text-7xl font-medium tracking-tight"
            >
              Here's a bit<br/>about me
            </motion.h1>
          </div>
        </div>

        {/* Info Grid Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 items-center mb-20 max-w-5xl mx-auto">
          
          {/* Left Column */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="space-y-12 text-center md:text-right md:pr-8"
          >
            <div>
              <p className="text-sm text-gray-500 mb-1">Experience:</p>
              <p className="text-base md:text-lg font-medium">+3 years</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Bachelor’s degree:</p>
              <p className="text-base md:text-lg font-medium leading-tight">Industrial<br/>Engineering</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Master’s degree:</p>
              <p className="text-base md:text-lg font-medium leading-tight">Engineering<br/>Design</p>
            </div>
          </motion.div>

          {/* Center Column (Image) */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex justify-center"
          >
            <div className="w-full max-w-[350px] aspect-[4/5] bg-[#FF7A00] rounded-[40px] overflow-hidden relative shadow-lg">
              <img 
                src="https://drive.google.com/thumbnail?id=1Hbd5EJi2pqFo_l9hBjkGK4mwpaCcTebO&sz=w800" 
                alt="Rousha Moshtaghian" 
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>

          {/* Right Column */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-12 text-center md:text-left md:pl-8"
          >
            <div>
              <p className="text-sm text-gray-500 mb-1">Location:</p>
              <p className="text-base md:text-lg font-medium leading-tight">Toronto, Ontario,<br/>Canada</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Availability:</p>
              <p className="text-base md:text-lg font-medium leading-tight">Open to<br/>opportunities</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Interests:</p>
              <p className="text-base md:text-lg font-medium leading-tight">Fitness, animals,<br/>and family time</p>
            </div>
          </motion.div>

        </div>

        {/* Start Project Button */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="flex justify-center mb-32"
        >
          <motion.a 
            href="mailto:roshamhtt@gmail.com"
            whileHover={{ scale: 1.05, backgroundColor: "#3f3f46" }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-zinc-800 text-white rounded-full font-medium transition-colors shadow-xl inline-block"
          >
            Start a Project
          </motion.a>
        </motion.div>

        {/* What I bring to the table Section */}
        <div className="pt-20 border-t border-gray-200/0 relative">
          <div className="flex justify-center mb-16">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-5xl md:text-7xl font-medium tracking-tight leading-tight text-center"
            >
              What I bring to the table
            </motion.h2>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-4 lg:gap-8 pt-10">
            
            {/* Card 1 */}
            <motion.div 
              initial={{ opacity: 0, y: 40, rotate: -5 }}
              whileInView={{ opacity: 1, y: 0, rotate: -3 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col transform origin-bottom-right"
            >
              <div className="bg-[#FF7A00] text-white py-6 px-8">
                <h3 className="font-medium text-lg">Design & Strategy</h3>
              </div>
              <div className="p-8 flex-grow flex flex-col gap-4">
                <p className="text-lg font-medium border-b border-gray-100 pb-3">UX Strategy</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">UI Design</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Wireframing</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Visual Hierarchy</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Responsive Layouts</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Brand Identity</p>
                <p className="text-lg font-medium pb-1">Content Design</p>
              </div>
            </motion.div>

            {/* Card 2 */}
            <motion.div 
              initial={{ opacity: 0, y: 40, rotate: 0 }}
              whileInView={{ opacity: 1, y: 0, rotate: 2 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col transform origin-bottom z-10 md:-mt-8"
            >
              <div className="bg-[#2563EB] text-white py-6 px-8">
                <h3 className="font-medium text-lg">Research & Optimization</h3>
              </div>
              <div className="p-8 flex-grow flex flex-col gap-4">
                <p className="text-lg font-medium border-b border-gray-100 pb-3">User Research</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">User Flows</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">A/B Testing</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">User Testing</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Usability Validation</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Engagement Analysis</p>
                <p className="text-lg font-medium pb-1">Conversion Optimization</p>
              </div>
            </motion.div>

            {/* Card 3 */}
            <motion.div 
              initial={{ opacity: 0, y: 40, rotate: 5 }}
              whileInView={{ opacity: 1, y: 0, rotate: -2 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white rounded-3xl shadow-xl overflow-hidden flex flex-col transform origin-bottom-left"
            >
              <div className="bg-[#10B981] text-white py-6 px-8">
                <h3 className="font-medium text-lg">Tools & Platforms</h3>
              </div>
              <div className="p-8 flex-grow flex flex-col gap-4">
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Figma</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">FigJam</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">WordPress</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">AI tools</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Canva</p>
                <p className="text-lg font-medium border-b border-gray-100 pb-3">Adobe Photoshop</p>
                <p className="text-lg font-medium pb-1">CapCut</p>
              </div>
            </motion.div>

          </div>
        </div>

        {/* Things that don't fit on my CV Section */}
        <div className="pt-32 pb-20 relative text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-4xl font-medium text-gray-900 mb-12">
              Things that don't fit on my <span className="relative inline-block">CV:
                <motion.svg
                  viewBox="0 0 100 100"
                  fill="none"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="absolute -top-5 -right-6 md:-top-6 md:-right-8 w-8 h-8 md:w-10 md:h-10 rotate-12 pointer-events-none"
                >
                  <motion.circle 
                    cx="50" cy="50" r="40" 
                    initial={{ pathLength: 0, opacity: 0 }} 
                    whileInView={{ 
                      pathLength: [0, 1, 1, 0, 0, 0],
                      stroke: ["#FACC15", "#FACC15", "#e5e7eb", "#e5e7eb", "#e5e7eb", "#e5e7eb"],
                      opacity: [0, 1, 1, 0, 0, 0]
                    }} 
                    viewport={{ once: false }}
                    transition={{ duration: 10, times: [0, 0.2, 0.8, 0.85, 0.95, 1], repeat: Infinity, ease: "linear" }} 
                  />
                  <motion.circle 
                    cx="35" cy="40" r="5" stroke="none"
                    initial={{ scale: 0, opacity: 0 }} 
                    whileInView={{ 
                      scale: [0, 1, 1, 0, 0, 0],
                      fill: ["#FACC15", "#FACC15", "#e5e7eb", "#e5e7eb", "#e5e7eb", "#e5e7eb"],
                      opacity: [0, 1, 1, 0, 0, 0]
                    }} 
                    viewport={{ once: false }}
                    transition={{ duration: 10, times: [0, 0.2, 0.8, 0.85, 0.95, 1], repeat: Infinity, ease: "linear" }} 
                  />
                  <motion.circle 
                    cx="65" cy="40" r="5" stroke="none"
                    initial={{ scale: 0, opacity: 0 }} 
                    whileInView={{ 
                      scale: [0, 1, 1, 0, 0, 0],
                      fill: ["#FACC15", "#FACC15", "#e5e7eb", "#e5e7eb", "#e5e7eb", "#e5e7eb"],
                      opacity: [0, 1, 1, 0, 0, 0]
                    }} 
                    viewport={{ once: false }}
                    transition={{ duration: 10, times: [0, 0.2, 0.8, 0.85, 0.95, 1], repeat: Infinity, ease: "linear" }} 
                  />
                  <motion.path 
                    d="M30 60 Q50 75 70 60" 
                    initial={{ pathLength: 0, opacity: 0 }} 
                    whileInView={{ 
                      pathLength: [0, 1, 1, 0, 0, 0],
                      stroke: ["#FACC15", "#FACC15", "#e5e7eb", "#e5e7eb", "#e5e7eb", "#e5e7eb"],
                      opacity: [0, 1, 1, 0, 0, 0]
                    }} 
                    viewport={{ once: false }}
                    transition={{ duration: 10, times: [0, 0.2, 0.8, 0.85, 0.95, 1], repeat: Infinity, ease: "linear" }} 
                  />
                </motion.svg>
              </span>
            </h2>
            <ul className="space-y-6 text-xl md:text-2xl text-gray-600 mb-12 text-left mx-auto w-fit">
              <li className="flex items-start gap-3">
                <span className="text-black mt-1.5 md:mt-1">•</span>
                <span>Talking to AI like it’s a coworker.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-black mt-1.5 md:mt-1">•</span>
                <span>I sometimes test designs on my friends without telling them.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-black mt-1.5 md:mt-1">•</span>
                <span>Enjoy collaborating with people who challenge my ideas.</span>
              </li>
            </ul>
          </motion.div>
        </div>

      </main>
    </div>
  );
}
